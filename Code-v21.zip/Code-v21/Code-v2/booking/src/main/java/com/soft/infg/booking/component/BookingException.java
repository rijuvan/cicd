package com.soft.infg.booking.component;

public class BookingException extends RuntimeException  {
	
	public BookingException(String message){
		super(message);
	}
}
